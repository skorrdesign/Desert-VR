var APP_DATA = {
  "scenes": [
    {
      "id": "0-pano_1---day",
      "name": "Pano_1 - Day",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.48948371472853225,
        "pitch": 0.08901501698131753,
        "fov": 1.5478391989099702
      },
      "linkHotspots": [
        {
          "yaw": -0.8624184087513402,
          "pitch": 0.148147189876358,
          "rotation": 0,
          "target": "2-pano_3---panorama"
        },
        {
          "yaw": 2.52873699308034,
          "pitch": 0.09792975562371886,
          "rotation": 0,
          "target": "1-pano_2---panorama"
        },
        {
          "yaw": -2.06483647154071,
          "pitch": 0.009209654576750381,
          "rotation": 0,
          "target": "3-pano_4---panorama"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-pano_2---panorama",
      "name": "Pano_2 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.5478391989099702
      },
      "linkHotspots": [
        {
          "yaw": 0.957031501937422,
          "pitch": 0.03277233864103657,
          "rotation": 6.283185307179586,
          "target": "4-pano_5---panorama"
        },
        {
          "yaw": -0.04298688034715248,
          "pitch": 0.029135495976372994,
          "rotation": 0,
          "target": "5-pano_6---panorama"
        },
        {
          "yaw": -3.055848976921947,
          "pitch": 0.1650983023399757,
          "rotation": 0,
          "target": "0-pano_1---day"
        },
        {
          "yaw": 2.437804020038267,
          "pitch": 0.05590200306905935,
          "rotation": 0,
          "target": "3-pano_4---panorama"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-pano_3---panorama",
      "name": "Pano_3 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -2.0022534184192082,
        "pitch": 0.10875397193717617,
        "fov": 1.5478391989099702
      },
      "linkHotspots": [
        {
          "yaw": -0.11422258243104189,
          "pitch": -0.004758416710235025,
          "rotation": 0,
          "target": "3-pano_4---panorama"
        },
        {
          "yaw": -1.6542912670441634,
          "pitch": 0.1250203270306649,
          "rotation": 0,
          "target": "0-pano_1---day"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-pano_4---panorama",
      "name": "Pano_4 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.1947071070206832,
          "pitch": 0.12128091170284883,
          "rotation": 0,
          "target": "2-pano_3---panorama"
        },
        {
          "yaw": 0.14989393868129142,
          "pitch": 0.03919004108739088,
          "rotation": 0,
          "target": "1-pano_2---panorama"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-pano_5---panorama",
      "name": "Pano_5 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.5478391989099702
      },
      "linkHotspots": [
        {
          "yaw": -2.0127953376734418,
          "pitch": 0.10830054027900005,
          "rotation": 0.7853981633974483,
          "target": "1-pano_2---panorama"
        },
        {
          "yaw": -1.164458336790247,
          "pitch": 0.0614468155396537,
          "rotation": 0,
          "target": "5-pano_6---panorama"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5-pano_6---panorama",
      "name": "Pano_6 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.11846787939515124,
        "pitch": 0.024903353447799148,
        "fov": 1.5478391989099702
      },
      "linkHotspots": [
        {
          "yaw": -0.5210153051945845,
          "pitch": 0.23404435340130547,
          "rotation": 0,
          "target": "1-pano_2---panorama"
        },
        {
          "yaw": -0.5014532137308514,
          "pitch": 0.05705923022333792,
          "rotation": 0,
          "target": "0-pano_1---day"
        },
        {
          "yaw": -2.4273556569765766,
          "pitch": 0.12720796041077165,
          "rotation": 0,
          "target": "4-pano_5---panorama"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Desert VR",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
